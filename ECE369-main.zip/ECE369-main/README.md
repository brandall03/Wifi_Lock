All codes we made/used in ECE369 :)
